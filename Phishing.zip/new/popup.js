document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("analyzeButton").addEventListener("click", analyzeEmail);
});

async function analyzeEmail() {
    let emailText = document.getElementById("emailInput").value;
    if (!emailText.trim()) {
        alert("Please paste an email to analyze.");
        return;
    }

    let score = 0;
    let issues = [];

    const phishingWords = [
        /urgent/i, /verify/i, /account locked/i, /confirm/i, /security alert/i,
        /password reset/i, /credit card/i, /bank account/i, /verify identity/i,
        /click here/i, /suspicious activity/i, /unauthorized login/i, /refund request/i
    ];

    phishingWords.forEach(word => {
        if (emailText.match(word)) {
            score += 15;
            issues.push(`⚠️ Suspicious phrase: "${word}"`);
        }
    });

    document.getElementById("results").innerHTML = `<strong>Phishing Risk Score: ${score}/100</strong><br>`;
    if (score < 25) {
        document.getElementById("results").innerHTML += "🟢 Safe - No obvious threats.";
    } else if (score < 50) {
        document.getElementById("results").innerHTML += "🟡 Suspicious - Be cautious!";
    } else {
        document.getElementById("results").innerHTML += "🔴 HIGH RISK - Likely a phishing email!";
    }
}