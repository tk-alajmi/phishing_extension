chrome.runtime.onInstalled.addListener(() => {
    console.log("Phishing Email Detector Installed!");
});